var app = Vue.createApp({
    // Vue.js 資料模型
    data: function() {
        return {
            message: 'This is a message.',
        };
    }
});
app.mount('#app');