var app = Vue.createApp({
    // Vue.js 資料模型
    data: function() {
        return {
            selectValue: ''
        };
    }
});
app.mount('#app');