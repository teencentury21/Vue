var app = Vue.createApp({
    // Vue.js 資料模型
    data: function() {
        return {
            content: '',
        };
    }
});
app.mount('#app');