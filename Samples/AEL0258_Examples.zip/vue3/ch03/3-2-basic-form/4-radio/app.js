var app = Vue.createApp({
    // Vue.js 資料模型
    data: function() {
        return {
            radioValue: '',
        };
    }
});
app.mount('#app');