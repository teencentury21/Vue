var app = new Vue({
    el: '#app',
    data: {
        message: 'This is a message.'
    },
});