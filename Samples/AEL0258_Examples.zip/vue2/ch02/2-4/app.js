var app = new Vue({
    el: '#app',
    data: {
        className: 'test-style-class ddd',
        customStyle: {
            width: '200px',
            margin: '5px',
            padding: '5px 10px',
            color: '#FEFEFE',
            background: '#666',
            'text-align': 'center'
        },
    }
});