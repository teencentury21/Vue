var app = new Vue({
    el: '#app',
    data: {
        message: 'This is a message.',
        counter: 10,
        foods: ['rice', 'apple', 'orange', 'cake'],
    },
});