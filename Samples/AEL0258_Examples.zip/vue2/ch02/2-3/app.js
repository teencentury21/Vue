var app = new Vue({
    el: '#app',
    data: {
        value1: '使用 v-bind 綁定資料',
        value2: '使用 v-bind 縮寫綁定資料',
    },
});