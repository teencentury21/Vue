import { myVar, myFunc } from './my-module.js';

console.log(myVar); // This is a module var.

const getFuncResult = myFunc(); // This is a module function.
console.log(getFuncResult)