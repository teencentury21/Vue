// 變數
export const myVar = 'This is a module var.';
// 方法
export function myFunc() {
    return 'This is a module function.';
};