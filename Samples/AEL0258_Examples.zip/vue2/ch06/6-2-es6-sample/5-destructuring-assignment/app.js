const [a, b, ...c] = [1, 2, 3, 4, 5];
console.log(`a: ${a}, b: ${b}, c: ${c}`);
const { x } = { x: 10, y: 20, z: 30};
console.log(`x: ${x}`);