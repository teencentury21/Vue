const myVar = 'Template String';
console.log(`字串變數 myVar: ${myVar}`);
const myArr = ['apple', 'banana', 'peach'];
console.log(`陣列變數 myArr: ${myArr}`);
const myObj = { name: '王大明', age: 25 };
console.log(`物件變數 myObj: ${JSON.stringify(myObj)}`);
