export default function myFunc() {
    return 'This is a module function.';
};