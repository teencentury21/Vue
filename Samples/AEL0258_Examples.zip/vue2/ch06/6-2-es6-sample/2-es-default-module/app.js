import myModule from './my-module.js';

// 取得並輸出 myFunc 回應值
const getFuncResult = myModule();
console.log(getFuncResult);
