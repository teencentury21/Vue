const myArr = [1, 2, 3];
console.log('原始 myArr:', myArr);
myArr.push(4);
console.log('新增數值4至 myArr:', myArr);

const myObj = { name: 'Origin Name', age: 25 };
console.log('原始 myObj:', myObj);
myObj.name = 'Modify Name';
console.log('修改屬性name myObj:', myObj);