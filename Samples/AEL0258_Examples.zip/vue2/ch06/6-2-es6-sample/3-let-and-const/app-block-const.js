{
    let myVar = 'local variable';
}

console.log(myVar);