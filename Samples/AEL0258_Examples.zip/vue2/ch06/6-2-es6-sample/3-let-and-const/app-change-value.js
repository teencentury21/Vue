let x = 1;
console.log('let x:');
console.log(x++);

const y = 1;
console.log('const y:');
console.log(y++);