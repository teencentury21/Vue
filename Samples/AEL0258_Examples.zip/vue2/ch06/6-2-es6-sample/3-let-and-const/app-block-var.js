{
    var myVar = 'local variable';
}

console.log(myVar);