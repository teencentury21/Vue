export default {
    ntd: 0,
    usdRate: 0,
    jpnRate: 0,
}