<template>
    <layout-content>
        活動清單
    </layout-content>
</template>

<script type="text/javascript">
import LayoutContent from './layouts/layout-content.vue';

export default {
    name: 'PageActivityList',
    data: function() {
        return {};
    },
    components: {
        LayoutContent,
    },
}
</script>

<style type="text/css" scoped>

</style>