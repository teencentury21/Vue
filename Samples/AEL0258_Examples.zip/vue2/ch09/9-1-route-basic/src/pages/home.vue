<template>
    <layout-content>
        Home
    </layout-content>
</template>

<script type="text/javascript">
import LayoutContent from './layouts/layout-content.vue';

export default {
    name: 'PageHome',
    data: function() {
        return {};
    },
    components: {
        LayoutContent,
    },
}
</script>

<style type="text/css" scoped>

</style>